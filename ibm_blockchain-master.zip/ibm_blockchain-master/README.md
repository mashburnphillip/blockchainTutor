# ibm_blockchain

Developing a blockchain application from scratch in Python

Explained in detail [here](https://www.ibm.com/developerworks/cloud/library/cl-develop-blockchain-app-in-python/index.html)
